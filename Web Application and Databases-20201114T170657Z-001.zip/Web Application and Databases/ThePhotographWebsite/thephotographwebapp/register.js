function registerProcess() {

//Set up XMLHttpRequest
    let xhttp = new XMLHttpRequest();

    //Extract user data
    let registerMemberId = document.getElementById("rgstrMemberId").value;
    let registerUsername = document.getElementById("rgstrUsername").value;
    let registerEmail = document.getElementById("rgstrEmail").value;
    let registerPassword = document.getElementById("rgstrPassword").value;


    //validations
    var letter = /[a-z]/;
    var upper  =/[A-Z]/;
    var number = /[0-9]/;

    //checks if input fields are empty
    if (registerMemberId == "" || registerUsername == "" || registerEmail == "" || registerPassword == ""  ) {
        toastr.options.positionClass = 'toast-top-center';
        toastr.warning("Fill up all fields");
        return;
    }

    //checking Length of MemberId
    if ( registerMemberId.length>5 || registerMemberId.length<5) {
        toastr.warning("Memberid can only be 5 characters long");
        return;
    }
    //checking Length of Password
    if(registerPassword.length < 8 ) {
        toastr.warning("Too weak, Password should be at least 8 characters");
        return;
    }

    //checking if password contains an Uppercase
    if(!upper.test(registerPassword)) {
        toastr.warning("Please make sure password includes an uppercase letter.");
        return ;
    }

    //checking if password includes a digit
    if(!number.test(registerPassword)){
        toastr.warning("Please make sure Password Includes a Digit")
        return;
    }

    //checking if password includes a lowercase character
    if(!letter.test(registerPassword)) {
        toastr.warning("Please make sure password includes a lowercase letter.")
    }

    //Create object with user data
        let member = {
            id: registerMemberId,
            name: registerUsername,
            email: registerEmail,
            pass: registerPassword,

        };

    //Set up function that is called when reply received from server
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {

            if (xhttp.responseText == "success") {
               toastr.success("User added successfully");
                setTimeout( console.log("on ready success"), 2000);
            } else {
                toastr.error("User already exist please login");
                setTimeout(console.log("On ready dublicate"), 2000);
            }
        }
    };

    //Send new user data to server
    xhttp.open("POST", "/registermember", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify(member));
}