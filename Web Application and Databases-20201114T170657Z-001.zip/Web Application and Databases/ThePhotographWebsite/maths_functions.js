//Returns true if email is valid
export function validateEmail(email) {
    const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());

}

//Returns the sum of two numbers
export function checkStorage(user){
    let contain=false;
    if(user!=null) {
        sessionStorage.setItem(user,user);
        if(sessionStorage.length>0) {
            contain = true;
        }
    }
    sessionStorage.removeItem(user);
    return contain;
}


