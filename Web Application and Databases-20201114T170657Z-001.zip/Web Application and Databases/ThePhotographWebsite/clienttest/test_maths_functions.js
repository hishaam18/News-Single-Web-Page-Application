//File containing the functions that we are testing
import {validateEmail, checkStorage} from '../maths_functions.js';

//Import expect from chai
let expect = chai.expect;

//Mocha test for multiply function
describe('#testEmail', () => {
    it('should return true if email is valid', (done) => {
        //Run some tests that sensibly explore the behaviour of the function
        let result = validateEmail("hisham@gmail.com");
        expect(result).to.equal(true);

        result = validateEmail("notanemail");
        expect(result).to.equal(false);

        //Call function to signal that test is complete
        done();
    });
});

//Mocha test for sum function
describe('#testSession', () => {
    it('should return true if user is not null', (done) => {
        //Run some tests that sensibly explore the behaviour of the function
        let result = checkStorage("hisham");
        expect(result).to.equal(true);

        result = checkStorage(null);
        expect(result).to.equal(false);

        //Call function to signal that test is complete
        done();
    });
});

