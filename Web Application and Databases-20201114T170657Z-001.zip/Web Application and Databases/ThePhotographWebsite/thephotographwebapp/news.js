
function getnews() {

    let xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = () => {
        //Called when data returns from server
         if (xhttp.readyState == 4 && xhttp.status == 200) {
            //Convert JSON to a JavaScript object
            let newsArr = JSON.parse(xhttp.responseText);


//Creating table to display News
            let htmlStr = "<table>"
"<col width=100><col width=100><col width=100>";

             htmlStr += ("<style>" +
                 "table{   " + "width: 100%;" + "}" +
                 "h1 {\n" +
                 "  background-color: black;\n" +
                 "  color: white;\n" +
                 "column-span: all;" +
                "width: 100%;"+
                 "text-align: center"+ "}"+
                 "tr:hover {background-color: #dbd6cd;}"+
                 "tr:nth-child(odd) {background-color: white;" +
                 "text-align: center" + "}"+
                 "title{background-color: #2a2a2a}"+
                 "</style>");

           htmlStr += ("<h1>" + "NEWS"  + "</h1>");
             for(let key in newsArr){
                 htmlStr += ("<tr>"+ "<td colspan='2' id='title'>"+ "<b>" +  newsArr[key].Title+ "</b>"  +"</td>"+ "</tr>" + "<tr>" + "<td>"+"</td>" +" "+ "<td>" + newsArr[key].News +"</td>" + "</tr>");
             }

             //Add users to page.
             htmlStr += "</table>";
             document.getElementById("displaynews").innerHTML = htmlStr;
        }
    };

    xhttp.open("GET", "/news", true);
    xhttp.send();
}

