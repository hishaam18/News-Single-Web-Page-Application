//Import the express and body-parser modules
const express = require('express');
const bodyParser = require('body-parser');

//Import database functions
const db = require('./database');

//Create express app and configure it with body-parser
const app = express();
app.use(bodyParser.json());

//Set up express to serve static files from the directory called 'thephotograpghwebapp'
app.use(express.static('thephotographwebapp'));

//Set up application to handle GET requests sent to the news path
app.get('/news', handleGetRequest);//Returns all news

//Set up application to handle POST requests sent to the newsupload path
app.post('/newsupload', handlePostRequest);//Adds a new newsupload

//Start the app listening on port 8080
app.listen(8080);

//Handles GET requests to our web service
function handleGetRequest(request, response){
    //Split the path of the request into its components
    var pathArray = request.url.split("/");

    //Get the last part of the path
    var pathEnd = pathArray[pathArray.length - 1];

    //If path ends with 'customers' we return all customers
    if(pathEnd === 'news'){
        //Call function to return all customers
        db.getAllNews(response);
    }
    else{//The path is not recognized. Return an error message
        response.send("{error: 'Path not recognized'}")
    }
}

//Handles POST requests to our web service
function handlePostRequest(request, response){
    //Extract customer data
    let newNews = request.body;
    console.log("Data received: " + JSON.stringify(newNews));

    //Call function to add new addNews
    db.addNews(newNews.NewsId, newNews.news, newNews.Title,  response);
}

//Export server for testing
module.exports = app;

