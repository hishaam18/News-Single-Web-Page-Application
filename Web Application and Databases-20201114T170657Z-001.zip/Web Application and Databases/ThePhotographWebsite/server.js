//import modules
const express = require('express');
const bodyparser = require('body-parser');

//Import the mysql module and create a connection pool with user details
const mysql = require('mysql');

//Create a connection pool with the user details
const connectionPool = mysql.createPool({
    connectionLimit: 1,
    host: "localhost",
    user: "root",
    password: "",
    database: "first database",
    debug: false
});

let news=[];
//the express module is a function. WHen it is executed it returns an app object
const app = express();

//make use of body parser to use json strings
app.use(bodyparser.json());

//set up express to static files from directory called 'thephotographwebapp'
app.use(express.static('thephotographwebapp'));

function NewsPost (request, response) {

    //output data sent to server
    let recentNews = request.body;
    console.log("Data received: " + JSON.stringify(recentNews));

    //Build query
    let sql = "INSERT INTO news VALUES" +
        "('" + recentNews.newsid + "','" + recentNews.news + "','" + recentNews.title + "');";

    //Execute query and output results
    connectionPool.query(sql, (err, result) => {
        if (err) {//Check for errors
            console.error("Error executing query: " + JSON.stringify(err));
            response.send("error");
        } else {
            //console.log("success");
            response.send("success");
        }
    });
}

function RegMemberPost(request, response) {
    //output the data sent to server
    let newMember = request.body;
    console.log("Data received: " + JSON.stringify(newMember));

    //Build query
    let sql = "INSERT INTO member VALUES" +
        "('" + newMember.id + "','" + newMember.name + "','" + newMember.email + "','" + newMember.pass + "');";

    //Execute query and output results
    connectionPool.query(sql, (err, result) => {
        if (err) {//Check for errors
            console.error("Error executing query: " + JSON.stringify(err));
            response.send("error");
        } else {
            //console.log("success");
            response.send("success");
        }
    });

}

function processUserAuthentication(request, response) {

    //retrieve user credentials and store in userCredential object
    let userCredential =request.body;

    //output the data on console screen
    console.log("Data received" + JSON.stringify(userCredential));

    //Store username and password in appropriate variables
    let Username = request.body.username;
    let Password = request.body.password;

    //call authenticateUser function to authenticate user
     authenticateUser(Username, Password, response);
}

async  function authenticateUser(Username, Password, response) {
    let queryError;
    connectionPool.query('SELECT * FROM member WHERE MemberId = ? AND Password = ?', [Username,Password], function(error,results) {
        console.log(results);
        //verify if there is a result
        if (results.length > 0) {
            //no result found
            queryError =false;
        } else {
            //result found, hence valid credentials
            queryError = true;
        }
    });

    //use timeout to ensure query has been executed before sending a response
    setTimeout(() => {
        if (queryError) {
            //error response
            response.status(400 || 404).json("{Error access denied}");
        } else {
            //response with status 200
            response.send("Access Granted!");
        }
    },1000);
}

async function getNews() {

    //Build query
    let sql = "SELECT * FROM news";

    //Wrap the execution of the query in a promise
    return new Promise((resolve, reject) => {
        connectionPool.query(sql, (err, result) => {
            if (err) {//Check for errors
                reject("Error executing query: " + JSON.stringify(err));
            } else {//Resolve promise with results
                resolve(result);
            }
        });
    });
}

//Handles GET requests to our web service
function handleGetRequest(request, response){
    //Split the path of the request into its components
    var pathArray = request.url.split("/");

    //Get the last part of the path
    var pathEnd = pathArray[pathArray.length - 1];

    //If path ends with 'users' we return all users
    if(pathEnd === 'news'){
        getNews().then(result => {
            //Output News.
            news = JSON.stringify(result);
            //Do something else
          //  console.log(news);
            response.send(news);

    }).catch(err => {//Handle the error
    console.error(JSON.stringify(err));
});

    }

    //If the last part of the path is a valid user id, return data about that user
    else if (pathEnd in news) {
        response.send(news[pathEnd]);
    }

    //The path is not recognized. Return an error message
}

//Handles POST requests to our web service
function handlePostRequest(request, response){
    //Output the data sent to the server
    let newUser = request.body;
    console.log("Data received: " + JSON.stringify(newUser));

    //Add user to our data structure
    //Finish off the interaction.
    response.send("User added successfully.");
}

//set up application to handle both POST and GET requests
app.post('/authenticate', processUserAuthentication);
app.post('/registermember', RegMemberPost);//Adds a new member
app.post('/newsupload', NewsPost);//Adds a new news
app.get('/news', handleGetRequest);

//start the app listening on port 9000
app.listen(9000);
