//Executes function when Login Button is pressed
function loginProcess() {

    if (sessionStorage.length > 0 ) {
        toastr.options.positionClass = 'toast-top-center';
        toastr.warning(" User is already Logged in, please Logout first ");
    }

    //retireve text input from Login section
    let loginUsername = document.getElementById("lgmemberid").value;
    let loginPassword = document.getElementById("lgpassword").value;

    //checks if input fields are empty
    if (loginUsername == "" || loginPassword == "") {
        //display error message
        toastr.warning(" Please Fill in all fields ");
        return;

    }else {

        //set up XMLHTTPRequest
        let xhttp = new XMLHttpRequest();

        xhttp.onreadystatechange = function() {

            if (this.readyState == 4 && this.status == 200) {
                if (xhttp.responseText=='Access Granted!'){
                sessionStorage.setItem('Person', JSON.stringify(usrObj));
                toastr.success("Login successful");
                return;
            }
            } else if (this.readyState == 4 && this.status == 400) {
                toastr.error("Login failed, Please enter valid details");
            }
            }

        //create object with user data
        let usrObj = {
            username: loginUsername,
            password: loginPassword
        };

        //Request data from all users
        xhttp.open("POST", "/authenticate", true);
        xhttp.setRequestHeader("Content-type", "application/json");
        xhttp.send(JSON.stringify(usrObj));
    }

}
function logoutProcess() {
    sessionStorage.clear();
    toastr.success("Logout Successful!")
}

