-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 04, 2020 at 01:34 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `first database`
--

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `MemberId` varchar(5) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`MemberId`, `Name`, `Email`, `Password`) VALUES
('csc', 'csacsa', 'csacsacsa@csc', 'csacc'),
('daawd', 'dawdawd', 'dadawdn@dawaw', 'aweawewea'),
('hello', 'hishaam', 'hishaam@gmail.com', '1234'),
('lacas', 'de papel', 'papel@gmail.com', 'heya'),
('Ldsa_', 'dasdas', 'pablo@gmail.com', 'pablo12'),
('mariy', 'cruz', 'delgado@gmail.com', 'dsad'),
('moos', 'zxcv', 'qwer@qwer.com', 'asd1230'),
('myid', 'dsds', 'pablito@gmail.com', '1542'),
('M_c12', 'C-note', 'C-note@gmail.com', '123465'),
('M_h12', 'hishaam', 'hishaam@gmail.com', '123456'),
('M_h18', 'fsfsf', 'hishaam@gmail.com', 'fsaffsaf'),
('M_l12', 'Lincoln', 'Lincoln@gmail.com', '123456'),
('M_m12', 'Michael', 'Michael@gmail.com', '123456'),
('M_s12', 'Sucre', 'Sucre@gmail.com', '123456'),
('M_t12', 'Tancredi', 'Tancredi@gmail.com', '123456'),
('Nelso', 'Mandela', 'nelson@gmail.com', '123456'),
('sa', 'csacsacs', 'csacsacsa@csc', 'csacc'),
('tomcs', 'yo', 'sca@vdvd.com', 'mkcksmCc25');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `NewsId` varchar(50) NOT NULL,
  `News` varchar(50000) NOT NULL,
  `Title` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`NewsId`, `News`, `Title`) VALUES
('Fifth_News', 'Health leaders are calling for an urgent review to determine whether the UK is properly prepared for the "real risk" of a second wave of coronavirus.', 'UK must prepare for second wave crisis'),
('First_News', 'On January 26, 2020, a Sikorsky S-76B helicopter crashed in Calabasas, California, around 30 miles (48 kilometres) northwest of downtown Los Angeles, while en route from John Wayne Airport to Camarillo Airport. Nine people were on board, including retired professional basketball player Kobe Bryant, ', 'Helicopter Crash'),
('Fourth_News', 'European Union nations could block visitors from countries with severe coronavirus outbreaks, including the United States, according to officials involved in the talks.', 'EU blocking  travelers'),
('news1', 'testing news written in paracscsaacas', 'The corona virus outbreak'),
('Second_News', 'The Premier League is set to resume on Wednesday June 17, provided all safety tests are cleared.', 'Premier League'),
('Sixth_News', 'Boris Johnson and Keir Starmer are going head to head over the Government''s handling of the coronavirus crisis.\r\n\r\nThe two are speaking at Prime Minister''s Questions, the first held since the PM announced major relaxing of the lockdown measures in England.\r\n\r\nIt comes as the UK has been warned of  the ''real risk'' of a second wave of coronavirus.\r\n\r\nBritain''s leading medical experts have written an open letter calling for an urgent review of whether the country is properly prepared for another possible fight against Covid-19.\r\n\r\nEngland''s Chief Medical officer Chris Whitty has predicted the country will have to cope with Covid-19 for the "long haul until this time next year".\r\n\r\nHe urged Brits not to behave as they did before and as if "everything was fine" as it would cause an "uptick" in virus transmission.', 'Coronavirus UPDATES:'),
('Third_News', 'The country is trying to stop a new coronavirus outbreak from turning into a full-blown second wave of infections, after hundreds of people working at a meat processing plant in the western state of North-Rhine Westphalia became ill. It''s a serious situation, but the German government isn''t rushing ', 'Germany Corona Crisis');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`MemberId`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`NewsId`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
