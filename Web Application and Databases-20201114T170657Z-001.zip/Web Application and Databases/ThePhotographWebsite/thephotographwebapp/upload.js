function uploadingews() {

    if (sessionStorage.length == 0 ) {
        toastr.options.positionClass = 'toast-top-center';
        toastr.warning(" Please Login first ");
    }else {

//Set up XMLHttpRequest
        let xhttp = new XMLHttpRequest();

        let uploadTitle = document.getElementById("uploadTitle").value;
        let uploadId = document.getElementById("uploadId").value;
        let uploadNews = document.getElementById("uploadNews").value;

        //validations
        var letter = /[a-z]/;
        var upper = /[A-Z]/;
        var number = /[0-9]/;

        //checks if input fields are empty
        if (uploadId == "" || uploadNews == "" || uploadTitle == "") {
            //display error message
            toastr.warning(" Please Fill in all fields ");
            return;
        }

        if (uploadTitle.length > 30) {
            toastr.warning("The Title can only be 30 characters long");
            return;
        }

        if (uploadId.length > 5 || uploadId.length < 5) {
            toastr.warning("Newsid can only be 5 characters long");
            return;
        }

        let UploadedNews = {
            newsid: uploadId,
            news: uploadNews,
            title: uploadTitle,
        };

        //Set up function that is called when reply received from server
        xhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {

                if (xhttp.responseText == "success") {
                    toastr.success("News added successfully");
                    setTimeout(console.log("on ready success"), 2000);
                } else {
                    toastr.error("Error News already Exist");
                    setTimeout(console.log("On ready dublicate"), 2000);
                }
            }
        };

        //Send news data to server
        xhttp.open("POST", "/newsupload", true);
        xhttp.setRequestHeader("Content-type", "application/json");
        xhttp.send(JSON.stringify(UploadedNews));
    }
}